# Atelier Process — Version base de données SQL

Reprise fidèle du design, de la charte graphique et du concept de l'application
d'origine (portail, espace **Process**, espace **Qualité**), reconstruite en
**HTML / CSS / JavaScript pur**, avec une **vraie base de données SQL**
(SQLite, via le moteur **sql.js** — SQLite compilé en WebAssembly, exécuté
directement dans le navigateur).

## Démarrage

Ouvrir simplement `index.html` dans un navigateur (Chrome/Edge/Firefox),
**avec une connexion internet active** au premier chargement : la police,
Tailwind CSS et le moteur SQLite (sql.js) sont chargés depuis un CDN.
Ensuite, l'application et sa base de données fonctionnent hors-ligne
(toutes les données sont stockées localement dans le navigateur).

Aucune installation, aucun serveur, aucun `npm install` n'est nécessaire.

## Mots de passe par défaut (table `users`, modifiables dans l'appli)

| Espace   | Identifiant | Mot de passe    |
|----------|-------------|-----------------|
| Process  | process     | `Process12344`  |
| Qualité  | qualite     | `Qualite12345`  |
| Admin    | admin       | `Admin12345`    |

Ces identifiants sont modifiables à tout moment depuis
**Process → Utilisateurs & Mots de passe**.

## Architecture

```
index.html          Structure de la page + chargement des scripts
css/style.css        Styles additionnels (identiques aux tokens d'origine)
js/db.js              Couche base de données SQL (schéma, seed, CRUD)
js/charts.js          Rendu canvas de la courbe scrap (avec zoom mois → jour)
js/views.js            Écran Portail + éléments partagés
js/views_process.js    Espace Process (sidebar, dashboard, journal, etc.)
js/views_quality.js    Espace Qualité (déclarations scrap)
js/modals.js           Formulaires de saisie/édition
js/app.js               État, routage, câblage des événements
```

## Base de données SQL (6 tables)

1. **`part_numbers`** — référentiel Programmes / Part Numbers
   (part_number, sewing_job_id, section, min, max, nominal, correction)
2. **`machines`** — référentiel machines
   (machine_id, sn_amatec, code_id, projet, ligne, ip, pcb, version, correction_points, correction_tension)
3. **`interventions`** — journal des interventions Process
   (date, time, technician, operator, type, machine_id, part_number, section, corr_type, before_val, after_val, cause, scrap, scrap_qty, comment, projet, ligne)
4. **`scrap_declarations`** — déclarations Qualité
   (date, time, operator_name, quality_tech, machine_id, ligne, part_number, serial_number, projet, cause, qty, comment)
5. **`scrap_log`** — historique consolidé qui alimente la **courbe scrap**
   du tableau de bord. Chaque déclaration Qualité et chaque intervention
   marquée "scrap" y ajoute automatiquement une ligne
   (date, time, operator_name, machine_id, part_number, qty, cause, projet, source)
6. **`users`** — comptes et mots de passe (username, password, role, active)

Toute écriture (ajout / modification / suppression) déclenche une requête
SQL réelle (`INSERT` / `UPDATE` / `DELETE`), puis la base SQLite complète
est réexportée et sauvegardée automatiquement dans le navigateur
(`localStorage`).

## Export / Sauvegarde

Depuis **Process → Export / Import** :
- Téléchargement du fichier `.sqlite` complet (ouvrable avec DB Browser for SQLite, DBeaver, etc.)
- Import d'un fichier `.sqlite` pour restaurer une sauvegarde
- Export CSV de la table `scrap_log` (courbe scrap)
- Réinitialisation de la base aux données de démonstration

## Remarque technique

Cette version fonctionne entièrement côté client (pas de serveur), ce qui
permet de l'ouvrir directement en local. Si vous souhaitez héberger cette
base sur un vrai serveur SQL partagé entre plusieurs postes (MySQL/PostgreSQL
avec un backend), il suffit d'exposer les mêmes 6 tables via une API REST ;
la couche `db.js` a été conçue pour être facilement remplacée par des appels
`fetch()` vers cette API sans toucher au reste de l'interface.
